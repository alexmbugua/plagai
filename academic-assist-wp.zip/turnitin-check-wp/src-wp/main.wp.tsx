import React from 'react';
import ReactDOM from 'react-dom/client';
import { AuthProvider } from './AuthContext.wp';
import App from './App.wp';
import './index.css';

// Find the WordPress container
const container = document.getElementById('turnitin-check-root');

if (container) {
  // Clear loading state
  container.innerHTML = '';
  
  ReactDOM.createRoot(container).render(
    <React.StrictMode>
      <AuthProvider>
        <App />
      </AuthProvider>
    </React.StrictMode>
  );
}
