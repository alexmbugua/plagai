import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { User, AuthState } from '@/types';

declare global {
  interface Window {
    turnitinCheckAjax?: {
      ajaxUrl: string;
      nonce: string;
    };
  }
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  // Check for existing WordPress session on mount
  useEffect(() => {
    const checkSession = async () => {
      // WordPress handles session via cookies, so we check if user is logged in
      // This would need a custom endpoint to check current user
      setState(prev => ({ ...prev, isLoading: false }));
    };
    checkSession();
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const ajaxUrl = window.turnitinCheckAjax?.ajaxUrl || '/wp-admin/admin-ajax.php';
      const nonce = window.turnitinCheckAjax?.nonce || '';
      
      const formData = new FormData();
      formData.append('action', 'turnitin_check_auth');
      formData.append('nonce', nonce);
      formData.append('auth_action', 'login');
      formData.append('email', email);
      formData.append('password', password);
      
      const response = await fetch(ajaxUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
      });
      
      const data = await response.json();
      
      if (data.success) {
        const user: User = {
          id: data.data.user.id,
          email: data.data.user.email,
          name: data.data.user.name,
          createdAt: new Date(),
        };
        
        setState({
          user,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        throw new Error(data.data?.message || 'Login failed');
      }
    } catch (error) {
      setState(prev => ({ ...prev, isLoading: false }));
      throw error;
    }
  }, []);

  const register = useCallback(async (name: string, email: string, password: string) => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const ajaxUrl = window.turnitinCheckAjax?.ajaxUrl || '/wp-admin/admin-ajax.php';
      const nonce = window.turnitinCheckAjax?.nonce || '';
      
      const formData = new FormData();
      formData.append('action', 'turnitin_check_auth');
      formData.append('nonce', nonce);
      formData.append('auth_action', 'register');
      formData.append('name', name);
      formData.append('email', email);
      formData.append('password', password);
      
      const response = await fetch(ajaxUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
      });
      
      const data = await response.json();
      
      if (data.success) {
        const user: User = {
          id: data.data.user.id,
          email: data.data.user.email,
          name: data.data.user.name,
          createdAt: new Date(),
        };
        
        setState({
          user,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        throw new Error(data.data?.message || 'Registration failed');
      }
    } catch (error) {
      setState(prev => ({ ...prev, isLoading: false }));
      throw error;
    }
  }, []);

  const logout = useCallback(() => {
    // WordPress logout would need a custom endpoint
    // For now, just clear the local state
    setState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
    });
    
    // Redirect to WordPress logout
    window.location.href = '/wp-login.php?action=logout';
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
