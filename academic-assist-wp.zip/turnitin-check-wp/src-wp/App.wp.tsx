import { useState } from 'react';
import { AuthProvider } from './AuthContext.wp';
import Header from '@/sections/Header';
import Hero from '@/sections/Hero';
import About from '@/sections/About';
import Features from '@/sections/Features';
import Pricing from '@/sections/Pricing';
import HowItWorks from '@/sections/HowItWorks';
import Testimonials from '@/sections/Testimonials';
import CTA from '@/sections/CTA';
import Footer from '@/sections/Footer';
import LoginModal from '@/components/auth/LoginModal';
import RegisterModal from '@/components/auth/RegisterModal';
import Dashboard from '@/components/dashboard/Dashboard';
import './App.css';

function AppContent() {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);

  const openLogin = () => {
    setIsRegisterOpen(false);
    setIsLoginOpen(true);
  };

  const openRegister = () => {
    setIsLoginOpen(false);
    setIsRegisterOpen(true);
  };

  const openDashboard = () => {
    setIsDashboardOpen(true);
  };

  const closeDashboard = () => {
    setIsDashboardOpen(false);
  };

  const handleSelectPlan = (_plan: { id: string; name: string; price: number }) => {
    openRegister();
  };

  // If dashboard is open, show it (but not full-screen in WordPress context)
  if (isDashboardOpen) {
    return (
      <div className="turnitin-check-dashboard-wrapper">
        <button 
          onClick={closeDashboard}
          className="turnitin-check-back-btn"
        >
          ← Back to Home
        </button>
        <Dashboard onClose={closeDashboard} />
      </div>
    );
  }

  return (
    <div className="turnitin-check-app">
      <Header
        onLoginClick={openLogin}
        onRegisterClick={openRegister}
        onDashboardClick={openDashboard}
      />
      
      <main>
        <Hero onRegisterClick={openRegister} />
        <About />
        <Features />
        <HowItWorks />
        <Pricing onSelectPlan={handleSelectPlan} />
        <Testimonials />
        <CTA onRegisterClick={openRegister} />
      </main>

      <Footer />

      {/* Modals */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onRegisterClick={openRegister}
      />
      
      <RegisterModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        onLoginClick={openLogin}
      />
    </div>
  );
}

function App() {
  return <AppContent />;
}

export default App;
