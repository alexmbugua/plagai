<?php
/**
 * Plugin Name: AcademicAssist
 * Plugin URI: https://academicassist.com
 * Description: Student academic support platform - Plagiarism reports, AI detection, proofreading, citation help, and assignment assistance
 * Version: 1.0.0
 * Author: AcademicAssist
 * Author URI: https://academicassist.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: academicassist
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ACADEMIC_ASSIST_VERSION', '1.0.0');
define('ACADEMIC_ASSIST_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ACADEMIC_ASSIST_PLUGIN_URL', plugin_dir_url(__FILE__));

class Academic_Assist_Plugin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('academic_assist', array($this, 'render_app'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_academic_assist_auth', array($this, 'handle_auth'));
        add_action('wp_ajax_nopriv_academic_assist_auth', array($this, 'handle_auth'));
        add_action('wp_head', array($this, 'add_styles'));
    }
    
    public function add_styles() {
        echo '<style>
        .academic-assist-container {
            min-height: 100vh;
            position: relative;
        }
        .academic-assist-loading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 400px;
            gap: 20px;
        }
        .academic-assist-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #e9e9e9;
            border-top-color: #3557e7;
            border-radius: 50%;
            animation: academic-spin 1s linear infinite;
        }
        @keyframes academic-spin {
            to { transform: rotate(360deg); }
        }
        .academic-assist-loading p {
            font-family: "Inter", sans-serif;
            color: #6b7280;
            font-size: 16px;
        }
        #academic-assist-root {
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }
        </style>';
    }
    
    public function enqueue_scripts() {
        global $post;
        
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'academic_assist')) {
            $asset_dir = ACADEMIC_ASSIST_PLUGIN_URL . 'dist/';
            
            $css_file = $this->get_asset_file('assets', 'css');
            $js_file = $this->get_asset_file('assets', 'js');
            
            if ($css_file) {
                wp_enqueue_style(
                    'academic-assist-styles',
                    $asset_dir . $css_file,
                    array(),
                    ACADEMIC_ASSIST_VERSION
                );
            }
            
            if ($js_file) {
                wp_enqueue_script(
                    'academic-assist-script',
                    $asset_dir . $js_file,
                    array(),
                    ACADEMIC_ASSIST_VERSION,
                    true
                );
                
                wp_localize_script('academic-assist-script', 'academicAssistAjax', array(
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('academic_assist_nonce'),
                    'restUrl' => rest_url('academic-assist/v1/'),
                    'isLoggedIn' => is_user_logged_in(),
                    'currentUser' => is_user_logged_in() ? array(
                        'id' => get_current_user_id(),
                        'name' => wp_get_current_user()->display_name,
                        'email' => wp_get_current_user()->user_email,
                    ) : null,
                ));
            }
        }
    }
    
    private function get_asset_file($folder, $extension) {
        $dist_path = ACADEMIC_ASSIST_PLUGIN_DIR . 'dist/' . $folder . '/';
        
        if (!is_dir($dist_path)) {
            return false;
        }
        
        $files = glob($dist_path . 'index-*.' . $extension);
        
        if (!empty($files)) {
            return $folder . '/' . basename($files[0]);
        }
        
        return false;
    }
    
    public function render_app($atts) {
        $atts = shortcode_atts(array(
            'view' => 'full',
        ), $atts, 'academic_assist');
        
        ob_start();
        ?>
        <div id="academic-assist-root" class="academic-assist-container" data-view="<?php echo esc_attr($atts['view']); ?>">
            <div class="academic-assist-loading">
                <div class="academic-assist-spinner"></div>
                <p>Loading AcademicAssist...</p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'AcademicAssist',
            'AcademicAssist',
            'manage_options',
            'academic-assist',
            array($this, 'admin_page'),
            'dashicons-welcome-learn-more',
            30
        );
        
        add_submenu_page(
            'academic-assist',
            'Settings',
            'Settings',
            'manage_options',
            'academic-assist-settings',
            array($this, 'settings_page')
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>AcademicAssist</h1>
            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2>How to Use</h2>
                <p>Add the shortcode <code>[academic_assist]</code> to any page or post to display the application.</p>
                
                <h3>Features:</h3>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li>Plagiarism Reports (Powered by Turnitin)</li>
                    <li>AI Detection Reports</li>
                    <li>Professional Proofreading</li>
                    <li>Citation Help (APA, MLA, Chicago, Harvard)</li>
                    <li>Assignment Assistance</li>
                    <li>User registration and login</li>
                    <li>Wallet system with multiple payment options</li>
                </ul>
                
                <h3>Payment Methods Supported:</h3>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li>Bank Transfer</li>
                    <li>Cryptocurrency (BTC, ETH, USDT)</li>
                    <li>PayPal</li>
                    <li>Wise</li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>AcademicAssist Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('academic_assist_options');
                do_settings_sections('academic-assist-settings');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Telegram Bot Token</th>
                        <td>
                            <input type="text" name="academic_assist_telegram_token" 
                                   value="<?php echo esc_attr(get_option('academic_assist_telegram_token')); ?>" 
                                   class="regular-text">
                            <p class="description">Enter your Telegram bot token for order notifications</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">WhatsApp Number</th>
                        <td>
                            <input type="text" name="academic_assist_whatsapp" 
                                   value="<?php echo esc_attr(get_option('academic_assist_whatsapp')); ?>" 
                                   class="regular-text">
                            <p class="description">WhatsApp number for customer support</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Support Email</th>
                        <td>
                            <input type="email" name="academic_assist_email" 
                                   value="<?php echo esc_attr(get_option('academic_assist_email', get_option('admin_email'))); ?>" 
                                   class="regular-text">
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    public function handle_auth() {
        check_ajax_referer('academic_assist_nonce', 'nonce');
        
        $action = isset($_POST['auth_action']) ? sanitize_text_field($_POST['auth_action']) : '';
        
        if ($action === 'login') {
            $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            
            $user = wp_authenticate($email, $password);
            
            if (is_wp_error($user)) {
                wp_send_json_error(array('message' => $user->get_error_message()));
            } else {
                wp_set_current_user($user->ID);
                wp_send_json_success(array(
                    'user' => array(
                        'id' => $user->ID,
                        'email' => $user->user_email,
                        'name' => $user->display_name,
                    )
                ));
            }
        } elseif ($action === 'register') {
            $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
            $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            
            if (email_exists($email)) {
                wp_send_json_error(array('message' => 'Email already exists'));
            }
            
            $user_id = wp_create_user($email, $password, $email);
            
            if (is_wp_error($user_id)) {
                wp_send_json_error(array('message' => $user_id->get_error_message()));
            } else {
                wp_update_user(array(
                    'ID' => $user_id,
                    'display_name' => $name,
                ));
                
                update_user_meta($user_id, 'academic_assist_wallet', 0);
                
                wp_send_json_success(array(
                    'user' => array(
                        'id' => $user_id,
                        'email' => $email,
                        'name' => $name,
                    )
                ));
            }
        }
        
        wp_send_json_error(array('message' => 'Invalid action'));
    }
}

Academic_Assist_Plugin::get_instance();

add_action('admin_init', function() {
    register_setting('academic_assist_options', 'academic_assist_telegram_token');
    register_setting('academic_assist_options', 'academic_assist_whatsapp');
    register_setting('academic_assist_options', 'academic_assist_email');
});
