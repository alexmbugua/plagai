#!/bin/bash

# Build script for WordPress plugin
# This script modifies the React app to work within WordPress

echo "Building Turnitin Check for WordPress..."

# Navigate to the React app directory
cd /mnt/okcomputer/output/app

# Create WordPress-specific entry point
cat > src/main-wp.tsx << 'EOF'
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Find the WordPress container
const container = document.getElementById('turnitin-check-root');

if (container) {
  // Clear loading state
  container.innerHTML = '';
  
  ReactDOM.createRoot(container).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}
EOF

# Update vite.config to use WordPress entry
cat > vite.config.wp.ts << 'EOF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'src/main-wp.tsx'),
      },
      output: {
        entryFileNames: 'assets/index-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: (assetInfo) => {
          const info = assetInfo.name.split('.');
          const ext = info[info.length - 1];
          if (/\.(css)$/i.test(assetInfo.name)) {
            return 'assets/index-[hash][extname]';
          }
          return 'assets/[name]-[hash][extname]';
        },
      },
    },
    outDir: '../turnitin-check-wp/dist',
    emptyOutDir: true,
  },
})
EOF

# Build for WordPress
npx vite build --config vite.config.wp.ts

# Clean up temporary files
rm -f src/main-wp.tsx vite.config.wp.ts

echo "Build complete! WordPress plugin is ready in ../turnitin-check-wp/"
